package com.duoc.Controller;

import com.duoc.Controller.Command;
import com.duoc.View.Receiver;

/**
 *
 * @author: Carlos Barría Valdevenito
 * @fecha: Aug 26, 2024
 * @asignatura: Desarrollo Orientado A Objetos II
 * @actividad: Actividad Sumativa S3
 *
 */
public class ComandoConcreto implements Command {

    private Receiver receptor;

    public ComandoConcreto(Receiver receptor) {
        this.receptor = receptor;
    }

    public void ejecutar() {
        receptor.accion();
    }
}
