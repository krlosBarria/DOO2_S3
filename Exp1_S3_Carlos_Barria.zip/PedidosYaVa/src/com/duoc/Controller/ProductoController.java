
package com.duoc.Controller;

import com.duoc.Model.Producto;
import com.duoc.View.ProductoView;
import java.util.List;

/**
 *
 * @author: Carlos Barría Valdevenito
 * @fecha: Aug 26, 2024
 * @hora: 11:34:29 PM
 * @asignatura: Desarrollo Orientado A Objetos II
 *
 */
public class ProductoController {
    private ProductoView vista;
    private List<Producto> productos;

    public ProductoController(ProductoView vista, List<Producto> productos) {
        this.vista = vista;
        this.productos = productos;
    }
    
    public void mostrarProductos() {
        vista.mostrarProductos(productos);
    }
}
