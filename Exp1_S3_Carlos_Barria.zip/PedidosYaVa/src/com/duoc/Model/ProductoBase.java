
package com.duoc.Model;

/**
 *
 * @author: Carlos Barría Valdevenito
 * @fecha: Aug 26, 2024
 * @hora: 11:10:08 PM
 * @asignatura: Desarrollo Orientado A Objetos II
 *
 */
public class ProductoBase implements Component{
    private Producto producto;

    public ProductoBase(Producto producto) {
        this.producto = producto;
    }

    @Override
    public double aplicarDescuento(double precio) {
        return precio;
    }

    public Producto getProducto() {
        return producto;
    }
}
