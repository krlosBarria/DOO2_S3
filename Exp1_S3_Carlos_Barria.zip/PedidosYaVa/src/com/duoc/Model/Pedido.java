
package com.duoc.Model;

import java.util.List;

/**
 *
 * @author: Carlos Barría Valdevenito
 * @fecha: Aug 26, 2024
 * @asignatura: Desarrollo Orientado A Objetos II
 * @actividad: Actividad Sumativa S3
 *
 */
public class Pedido {
    private List<Producto> productos;
    private double total;
    
    

}
