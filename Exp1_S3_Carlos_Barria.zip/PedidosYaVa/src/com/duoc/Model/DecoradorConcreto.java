package com.duoc.Model;

import com.duoc.Model.Component;

/**
 *
 * @author: Carlos Barría Valdevenito
 * @fecha: Aug 26, 2024
 * @asignatura: Desarrollo Orientado A Objetos II
 * @actividad: Actividad Sumativa S3
 *
 */
public class DecoradorConcreto extends Decorator {

    public DecoradorConcreto(Component componente) {
        super(componente);
    }
//
//    @Override
//    public void operacion() {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
//    }

    public void operacion() {
        super.componente();
        //Agreagar fucionalidad adicional al componente
    }

    @Override
    public double aplicarDescuento(double precio) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}
