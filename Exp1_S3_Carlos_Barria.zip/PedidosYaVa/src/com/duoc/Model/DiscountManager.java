package com.duoc.Model;

/**
 *
 * @author: Carlos Barría Valdevenito
 * @fecha: Aug 26, 2024
 * @asignatura: Desarrollo Orientado A Objetos II
 * @actividad: Actividad Sumativa S3
 *
 */
public class DiscountManager {
    private static DiscountManager instancia; 
            
    //Constructor privado para evitar instancias indirectas
    private DiscountManager() {
    }
    
    public static synchronized DiscountManager getInstance(){
        if (instancia == null){
            instancia = new DiscountManager();
        }
        return instancia;
    }
    
    
}
