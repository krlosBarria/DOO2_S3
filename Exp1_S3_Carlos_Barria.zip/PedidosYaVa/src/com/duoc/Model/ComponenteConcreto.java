package com.duoc.Model;

import com.duoc.Model.Component;

/**
 *
 * @author: Carlos Barría Valdevenito
 * @fecha: Aug 26, 2024
 * @asignatura: Desarrollo Orientado A Objetos II
 * @actividad: Actividad Sumativa S3
 *
 */
public class ComponenteConcreto implements Component {

    public ComponenteConcreto() {
    }

    @Override
    public double aplicarDescuento(double precio) {
        return precio;
    }


}
