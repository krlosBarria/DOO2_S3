
package com.duoc.View;

/**
 *
 * @author: Carlos Barría Valdevenito
 * @fecha: Aug 26, 2024
 * @asignatura: Desarrollo Orientado A Objetos II
 * @actividad: Actividad Sumativa S3
 *
 */
public class DescuentoView {

}
