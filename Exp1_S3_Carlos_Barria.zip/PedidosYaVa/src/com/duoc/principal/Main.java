package com.duoc.principal;

import com.duoc.Controller.ProductoController;
import com.duoc.Controller.Singleton;
import com.duoc.Model.Pedido;
import com.duoc.Model.Producto;
import com.duoc.View.ProductoView;
import java.util.Scanner;

/**
 *
 * @author: Carlos Barría Valdevenito
 * @fecha: Aug 26, 2024
 * @asignatura: Desarrollo Orientado A Objetos II
 * @actividad: Actividad Sumativa S3
 *
 */
public class Main {
    private static Scanner teclado = new Scanner(System.in);
    private static int opcion;

    public static void main(String[] args) {

        do {
            menuPri();
            //Validacion de opcion ingresada sea correcta
            try {
                opcion = teclado.nextInt();
            } catch (Exception e) {
                System.out.println("*** Opcion No valida ***");
                opcion = 0;
                teclado.next(); //Limpiamos el buffer del scanner
            }

            switch (opcion) {
                case 1 ->
                    ingresaProducto();
                case 2 ->
                    eliminaProducto();
                case 3 ->
                    mostrarProductos();
                case 4 ->
                    mostrarCarrito();
                case 5 ->
                    System.out.println("Gracias por su visita, Adios.");
                default ->
                    System.out.println("Opcion fuera de rango.\n");
            }

        } while (opcion != 5);
        teclado.close();
    }

    //Menú principal
    static void menuPri() {
        String s = """
                  ------:Sistema de Descuentos - Tienda Online YaVa:------
                  1. Ingrese Producto al Carrito.
                  2. Eliminar Producto del Carrito.
                  3. Mostrar Productos.
                  4. Total Carrito.
                  5. Salir.
                  Seleccione su opcion:
                   """;
        System.out.println(s);
    }


    private static void ingresaProducto() {
        Producto producto1 = new Producto("Camiseta", 3000, "Deportes");
        Producto producto2 = new Producto("Pantalon", 4000, "Casual");
        Pedido pedido = new Pedido();
    }

    private static void eliminaProducto() {
        System.out.println("Elimina productos");
    }
    private static void mostrarCarrito() {
        System.out.println("Productos de Carrito");
        
    }

    private static void mostrarProductos() {
        System.out.println("Mostrar Productos");
        
    }
}
